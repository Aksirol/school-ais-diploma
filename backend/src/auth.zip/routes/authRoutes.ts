import { Router } from 'express';
import { body } from 'express-validator';
import { register, login } from '../controllers/authController';

const router = Router();

// Правила валідації для реєстрації
const registerValidation = [
  body('email').isEmail().withMessage('Невірний формат email або email відсутній'),
  body('password').isLength({ min: 8 }).withMessage('Пароль має містити мінімум 8 символів'),
  body('first_name').notEmpty().trim().escape().withMessage('Ім\'я обов\'язкове'),
  body('last_name').notEmpty().trim().escape().withMessage('Прізвище обов\'язкове'),
  body('role').isIn(['teacher', 'student']).withMessage('Недопустима роль. Доступні лише teacher та student')
];

router.post('/register', registerValidation, register);
router.post('/login', login);

export default router;